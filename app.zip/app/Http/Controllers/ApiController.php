<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Api;
use Str;
use Auth;

class ApiController extends Controller
{
    public function generateApi(Request $req) {
        $req->validate([
            'api_quota' => 'required',
            'extra_secure' => 'required|in:0,1',
            'total_requests' => 'required_if:api_quota,limited|numeric|max:20000',
            'security_header' => 'required_if:extra_secure,1|alpha_num',
        ]);
        do {
            $key = Str::random(20);
        } while (Api::where('key', $key)->exists());
        $api = Api::create([
           'user_id' => Auth::id(),
           'key' => $key,// 
           'api_quota' => $req->api_quota,
           'total_requests' => $req->total_requests,
           'extra_secure' => $req->extra_secure,
           'security_header' => $req->security_header,
        ]);
        return redirect()->back()->with('success', 'API key generated successfully!');
    }

    public function deleteApi($key) {
        $api = Api::where('user_id', Auth::id())->where('key', $key)->first();
        if($api) {
            $api->delete();
            return redirect()->back()->with('success', 'API key deleted successfully!');
        }
        else {
            return redirect()->back()->with('error', 'Invalid action!');
        }
    }
    public function editApi($key) {
        $api = Api::where('user_id', Auth::id())->where('key', $key)->first();
        if($api) {
            return view('inner.user-editApi', compact('api'));
        }
        else {
            return redirect()->back()->with('error', 'Invalid action!');
        }
    }

    public function updateApi(Request $req) {
        $req->validate([
            'api_quota' => 'required',
            'extra_secure' => 'required|in:0,1',
            'total_requests' => 'required_if:api_quota,limited|numeric|max:20000',
            'security_header' => 'required_if:extra_secure,1|alpha_num',
        ]);
        $api = Api::where('key', $req->key)->where('user_id', Auth::id())->update([
           'api_quota' => $req->api_quota,
           'total_requests' => $req->total_requests,
           'extra_secure' => $req->extra_secure,
           'security_header' => $req->security_header,
        ]);
        return redirect()->back()->with('success', 'API key updated successfully!');
    }

    public function changeApiStatus($key) {
        $api = Api::where('user_id', Auth::id())->where('key', $key)->first();
        if($api) {
            $api->status = $api->status == 1 ? 0 : 1;
            $api->save();
            return redirect()->back()->with('success', 'API key updated successfully!');
        }
        else {
            return redirect()->back()->with('error', 'Invalid action!');
        }
    }

}
