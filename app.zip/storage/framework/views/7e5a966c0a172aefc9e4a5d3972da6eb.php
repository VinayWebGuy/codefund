
<?php $__env->startSection('title', 'OTP'); ?>
<?php $__env->startSection('content'); ?>
    <form action="">
      <div class="otp-group">
        <input type="number" class="otp-input" name="otp[]">
        <input type="number" class="otp-input" name="otp[]">
        <input type="number" class="otp-input" name="otp[]">
        <input type="number" class="otp-input" name="otp[]">
        <input type="number" class="otp-input" name="otp[]">
        <input type="number" class="otp-input" name="otp[]">
      </div>
        <button class="btn primary full">Proceed</button>
        <div class="links single">
            <a href="<?php echo e(url('login')); ?>">Logout?</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\laravel-10.x\resources\views/otp.blade.php ENDPATH**/ ?>