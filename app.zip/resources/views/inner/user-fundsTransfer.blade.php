@extends('inner.layouts.main')
@section('title', 'Funds Transfer')
@section('user-funds-transfer', 'active')
@section('user-need-wallet', 'locked')
@section('content')
    <div class="container">
        <h4>Funds Transfer</h4>
        <h3>Send</h3>
        <form action="">
            <div class="row">
                <div class="group">
                    <label for="amount">Amount</label>
                    <input type="number" step=".1" name="amount" id="amount">
                </div>
                <div class="group">
                    <label for="account_number">Account number</label>
                    <input type="text"  name="account_number" id="account_number">
                </div>
            </div>
            <button class="btn primary">Send</button>
            <button type="reset" class="btn danger">Reset</button>
        </form>
        <hr>
        <h3>Request</h3>
        <form action="">
            <div class="row">
                <div class="group">
                    <label for="amount">Amount</label>
                    <input type="number" step=".1" name="amount" id="amount">
                </div>
                <div class="group">
                    <label for="account_number">Account number</label>
                    <input type="text"  name="account_number" id="account_number">
                </div>
            </div>
            <button class="btn primary">Request</button>
            <button type="reset" class="btn danger">Reset</button>
        </form>
    </div>
@endsection