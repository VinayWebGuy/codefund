
<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('user-profile', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4>Profile</h4>
        <div class="profile-details">
            <p>Account number</p>
            <p>

                <?php if(!$wallet_account): ?><a href="<?php echo e(url('main/user/create-account')); ?>" class="btn warning sm">Create Account</a> <?php else: ?> <?php echo e($wallet_account->account_number); ?> <?php endif; ?>
            </p>
        </div>
        <div class="profile-details">
            <p>Name</p>
            <p><?php echo e(Auth::user()->name); ?></p>
        </div>
        <div class="profile-details">
            <p>Email</p>
            <p><?php echo e(Auth::user()->email); ?></p>
        </div>
        <div class="profile-details">
            <p>Identification Type</p>
            <p><?php echo e(ucfirst(Auth::user()->identification_type)); ?></p>
        </div>
        <div class="profile-details">
            <p>Identification Number</p>
            <p><?php echo e(Auth::user()->identification_number); ?></p>
        </div>
      
    </div>

    
    <?php if(session('success')): ?>
    <div class="toastr success">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>
  
  <?php if(session('error')): ?>
    <div class="toastr error">
      <?php echo e(session('error')); ?>

    </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inner.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\laravel-10.x\resources\views/inner/user-profile.blade.php ENDPATH**/ ?>