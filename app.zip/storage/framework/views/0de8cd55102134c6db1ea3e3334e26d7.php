
<?php $__env->startSection('title', 'Forget Password'); ?>
<?php $__env->startSection('content'); ?>
    <form action="">
        <div class="group">
            <label for="email">Email</label>
            <input type="email" name="email" id="email">
        </div>
        <button class="btn primary full">Reset</button>
        <div class="links single">
            <a href="<?php echo e(url('login')); ?>">Back to Login</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\laravel-10.x\resources\views/forget-password.blade.php ENDPATH**/ ?>