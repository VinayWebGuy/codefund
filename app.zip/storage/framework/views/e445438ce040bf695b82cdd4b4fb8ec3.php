<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/prism/1.5.0/themes/prism.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
    <?php
        $checkAccount = DB::table('wallet_accounts')->where('user_id', Auth::id())->first();
        $route = Auth::user()->role == 1 ? 'user' : 'admin';
    ?>
    <div class="inner">
        <nav>
            <div class="logo">
                <a href="<?php echo e(url('main')); ?>/<?php echo e($route); ?>"><?php echo e(AppInfo('name')); ?></a>
            </div>
            <?php if(Auth::user()->role == 1): ?>
            <div class="menu">
                <li class="<?php echo $__env->yieldContent('user-add-funds'); ?>"><a href="<?php echo e(url('main/user/funds/add')); ?>">Add Funds</a></li>
                <li class="<?php echo $__env->yieldContent('user-funds-transfer'); ?>"><a href="<?php echo e(url('main/user/funds/transfer')); ?>">Funds Transfer</a></li>
                <li class="<?php echo $__env->yieldContent('user-api'); ?>"><a href="<?php echo e(url('main/user/api')); ?>">API</a></li>
                <li class="<?php echo $__env->yieldContent('user-profile'); ?>"><a href="<?php echo e(url('main/user/profile')); ?>">Profile</a></li>
                <li><a href="<?php echo e(route('user.logout')); ?>">Logout</a></li>
                <li class="balance">Wallet : <?php echo e(Auth::user()->wallet_balance); ?></li>
            </div>
            <?php else: ?> 
          <div class="menu">
            <li class="<?php echo $__env->yieldContent('user-profile'); ?>"><a href="<?php echo e(url('main/user/profile')); ?>">Profile</a></li>
            <li><a href="<?php echo e(route('user.logout')); ?>">Logout</a></li>
          </div>

            <?php endif; ?>
        </nav>
        <div class="content <?php if(!$checkAccount ): ?><?php echo $__env->yieldContent('user-need-wallet'); ?> <?php endif; ?>"><?php /**PATH C:\xampp\htdocs\Laravel\laravel-10.x\resources\views/inner/layouts/header.blade.php ENDPATH**/ ?>