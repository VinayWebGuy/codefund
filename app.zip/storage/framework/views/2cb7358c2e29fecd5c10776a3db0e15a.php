
<?php $__env->startSection('title', 'Register'); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('user.register')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="group">
            <label for="name">Name</label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="group">
            <label for="email">Email</label>
            <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="group">
            <label for="password">Password</label>
            <input type="password" name="password" id="password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="group">
            <label for="confirm_password">Confirm Password</label>
            <input type="password" name="confirm_password" id="confirm_password">
            <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="group">
            <label for="pin_code">Pin code</label>
            <input value="<?php echo e(old('pin_code')); ?>" type="number" name="pin_code" id="pin_code">
            <?php $__errorArgs = ['pin_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="group">
            <label for="identification_type">Identifcation Type</label>
            <select name="identification_type" id="identification_type">
                <option value="" hidden>Choose</option>
                <option <?php echo e(old('identification_type') === 'pan_card' ? 'selected' : ''); ?> value="pan_card">Pan Card</option>
                <option <?php echo e(old('identification_type') === 'passport' ? 'selected' : ''); ?> value="passport">Passport
                </option>
                <option <?php echo e(old('identification_type') === 'driving_license' ? 'selected' : ''); ?> value="driving_license">
                    Driving License</option>
            </select>
            <?php $__errorArgs = ['identification_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="group">
            <label for="identification_number">Identification Number</label>
            <input value="<?php echo e(old('identification_number')); ?>" type="text" name="identification_number"
                id="identification_number">
            <?php $__errorArgs = ['identification_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="btn primary full">Register</button>
        <div class="links single">
            <a href="<?php echo e(url('login')); ?>">Already have an account?</a>
        </div>
    </form>

    <?php if(session('success')): ?>
    <div class="toastr success">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>
  
  <?php if(session('error')): ?>
    <div class="toastr error">
      <?php echo e(session('error')); ?>

    </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\laravel-10.x\resources\views/register.blade.php ENDPATH**/ ?>