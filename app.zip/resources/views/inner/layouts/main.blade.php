@include('inner.layouts.header')
@yield('content')
@include('inner.layouts.footer')