@extends('inner.layouts.main')
@section('title', 'Add Funds')
@section('user-add-funds', 'active')
@section('user-need-wallet', 'locked')
@section('content')
    <div class="container">
        <h4>Add Funds</h4>
        <form action="">
            <div class="row">
                <div class="group">
                    <label for="ref_id">Reference Id</label>
                    <input type="text" name="ref_id" id="ref_id">
                </div>
                <div class="group">
                    <label for="amount">Amount</label>
                    <input type="number" step=".1" name="amount" id="amount">
                </div>
                <div class="group">
                    <label for="secret_code">Secret Code</label>
                    <input type="password" name="secret_code" id="secret_code">
                </div>
            </div>
            <button class="btn primary">Add</button>
            <button type="reset" class="btn danger">Reset</button>
        </form>
    </div>

    
@endsection