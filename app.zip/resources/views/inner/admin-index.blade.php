@extends('inner.layouts.main')
@section('title', 'Home')
@section('content')
    <div class="blocks">
        <div class="block">
            <span>{{ format_number(15870) }}</span>
            <span>Total Users</span>
        </div>
        <div class="block">
            <span>{{ format_number(24058) }}</span>
            <span>API Created</span>
        </div>
        <div class="block">
            <span>{{ format_number(890004820) }}</span>
            <span>Completed Transactions</span>
        </div>
        <div class="block">
            <span>{{ format_number(17202880) }}</span>
            <span>Failed Transactions</span>
        </div>
    </div>
    <div class="table">
        <h4>Recent Transactions</h4>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Txn Id</th>
                    <th>Amount</th>
                    <th>Datetime</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>12547828989</td>
                    <td>{{ format_number(250) }}</td>
                    <td>2024-09-24 12:25 PM</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>1558745488445</td>
                    <td>{{ format_number(18000) }}</td>
                    <td>2024-09-24 12:25 PM</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>8210488484125</td>
                    <td>{{ format_number(30631) }}</td>
                    <td>2024-09-24 12:25 PM</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>12547828989</td>
                    <td>{{ format_number(250) }}</td>
                    <td>2024-09-24 12:25 PM</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>1558745488445</td>
                    <td>{{ format_number(18000) }}</td>
                    <td>2024-09-24 12:25 PM</td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>8210488484125</td>
                    <td>{{ format_number(30631) }}</td>
                    <td>2024-09-24 12:25 PM</td>
                </tr>
            </tbody>
        </table>
    </div>
@endsection
