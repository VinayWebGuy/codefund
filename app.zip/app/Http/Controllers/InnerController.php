<?php

namespace App\Http\Controllers;
use App\Models\Api;
use App\Models\WalletAccount;
use Auth;

use Illuminate\Http\Request;

class InnerController extends Controller
{
    public function adminIndex() {
        return view('inner.admin-index');
    }
    public function userIndex() {
        return view('inner.user-index');
    }

    public function apiManager() {
        $keys = Api::where('user_id', Auth::id())->get();
        return view('inner.user-apiManager', compact('keys'));
    }
    public function apiUsage() {
        return view('inner.user-apiUsage');
    }
    public function addFunds() {
        return view('inner.user-addFunds');
    }
    public function fundsTransfer() {
        return view('inner.user-fundsTransfer');
    }
    public function profile() {
        $wallet_account = WalletAccount::where('user_id', Auth::id())->first();
        return view('inner.user-profile', compact('wallet_account'));
    }

    public function createAccount() {
        // Check account is created or not
        $account = WalletAccount::where('user_id',  Auth::id())->first();
        if(!$account) {
            do {
                $account_number = rand(1111111111111, 99999999999999);
            } while (WalletAccount::where('account_number', $account_number)->exists());
            $ac = WalletAccount::create([
                'user_id' => Auth::id(),
                'account_number' => $account_number
            ]);
            return redirect()->back()->with('success', 'Wallet account generated successfully!');
        }
        else {
            return redirect('main/user/profile')->with('error', 'Wallet Account already created');
        }
    }


    public function mainIndex() {
        if(Auth::user()->role == 1) {
            return redirect('main/user');
        }
        else {
            return redirect('main/admin');
        }
    }
}
