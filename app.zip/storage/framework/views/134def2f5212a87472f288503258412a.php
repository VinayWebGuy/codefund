
<?php $__env->startSection('title', 'API Manager'); ?>
<?php $__env->startSection('user-api', 'active'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <h4>Update API Key</h4>
        <form action="<?php echo e(route('update.key')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="key" value="<?php echo e($api->key); ?>">
            <div class="row form">
                <div class="group">
                    <label for="api_quota">API Quota</label>
                    <select name="api_quota" id="api_quota">
                        <option <?php echo e($api->api_quota === 'limited' ? 'selected' : ''); ?> value="limited">Limited</option>
                        <option <?php echo e($api->api_quota === 'unlimited' ? 'selected' : ''); ?> value="unlimited">Unlimited</option>
                    </select>
                    <?php $__errorArgs = ['api_quota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="group">
                    <label for="total_requests">Total Requests</label>
                   <input type="number" name="total_requests" id="total_requests" value="<?php echo e($api->total_requests); ?>" <?php echo e($api->api_quota == 'unlimited' ? "disabled": ""); ?> min="1" max="25000">
                   <?php $__errorArgs = ['total_requests'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="error"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row form">
                <div class="group">
                    <label for="extra_secure">Extra Secure</label>
                    <select name="extra_secure" id="extra_secure">
                        <option <?php echo e($api->extra_secure == 0 ? 'selected' : ''); ?> value="0">No</option>
                        <option <?php echo e($api->extra_secure == 1 ? 'selected' : ''); ?> value="1">Yes</option>
                    </select>
                    <?php $__errorArgs = ['extra_secure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="group sec_header">
                    <label for="security_header">Security Header</label>
                   <input type="text" name="security_header" id="security_header" value="<?php echo e($api->security_header); ?>" <?php echo e($api->security_header == 0 ? "disabled": ""); ?>>
                   <?php $__errorArgs = ['security_header'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="error"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <button class="btn primary">Update</button>
            <button type="reset" class="btn danger">Cancel</button>

        </form>
    </div>

    <?php if(session('success')): ?>
    <div class="toastr success">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>
  
  <?php if(session('error')): ?>
    <div class="toastr error">
      <?php echo e(session('error')); ?>

    </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inner.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\laravel-10.x\resources\views/inner/user-editApi.blade.php ENDPATH**/ ?>