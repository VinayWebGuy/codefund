
<?php $__env->startSection('title', 'API Manager'); ?>
<?php $__env->startSection('user-api', 'active'); ?>
<?php $__env->startSection('user-need-wallet', 'locked'); ?>
<?php $__env->startSection('content'); ?>

    <div class="table container">
        <h4 class="row">My Api Keys
            <a href="<?php echo e(url('main/user/api/usage')); ?>" class="btn primary sm">How to use?</a>
        </h4>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>API Key</th>
                    <th>Total Requests</th>
                    <th>Requests Left</th>
                    <th>Additional Security</th>
                    <th>Security Header</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(count($keys) > 0): ?>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $keys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($key->key); ?></td>
                    <td><?php echo e($key->api_quota == 'unlimited' ? "Unlimited" : $key->total_requests); ?></td>
                    <td><?php echo e($key->api_quota == 'unlimited' ? "Unlimited" : $key->total_requests - $key->request_hit); ?></td>
                    <td><?php echo e($key->extra_secure == 1 ? "Yes" : "No"); ?></td>
                    <td class="blur"><?php echo e($key->security_header); ?></td>
                    <td>
                        <a href="<?php echo e(url('main/user/api/delete')); ?>/<?php echo e($key->key); ?>" class="btn danger sm">Delete</a>
                        <a href="<?php echo e(url('main/user/api/edit')); ?>/<?php echo e($key->key); ?>" class="btn warning sm">Edit</a>
                        <?php if($key->status == 1): ?>
                        <a href="<?php echo e(url('main/user/api/change-status')); ?>/<?php echo e($key->key); ?>" class="btn primary sm">Active</a>
                        <?php else: ?>
                        <a href="<?php echo e(url('main/user/api/change-status')); ?>/<?php echo e($key->key); ?>" class="btn danger sm">Inactive</a>
                        <?php endif; ?>
                    </td>
                </tr>   
                <?php $i++ ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7"> No key generated yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="container">
        <h4>Create New Key</h4>
        <form action="<?php echo e(route('generate.key')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row form">
                <div class="group">
                    <label for="api_quota">API Quota</label>
                    <select name="api_quota" id="api_quota">
                        <option <?php echo e(old('api_quota') === 'limited' ? 'selected' : ''); ?> value="limited">Limited</option>
                        <option <?php echo e(old('api_quota') === 'unlimited' ? 'selected' : ''); ?> value="unlimited">Unlimited</option>
                    </select>
                    <?php $__errorArgs = ['api_quota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="group">
                    <label for="total_requests">Total Requests</label>
                   <input type="number" name="total_requests" id="total_requests" value="<?php echo e(old('total_requests')); ?>" min="1" max="25000">
                   <?php $__errorArgs = ['total_requests'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="error"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="row form">
                <div class="group">
                    <label for="extra_secure">Extra Secure</label>
                    <select name="extra_secure" id="extra_secure">
                        <option <?php echo e(old('extra_secure') == 0 ? 'selected' : ''); ?> value="0">No</option>
                        <option <?php echo e(old('extra_secure') == 1 ? 'selected' : ''); ?> value="1">Yes</option>
                    </select>
                    <?php $__errorArgs = ['extra_secure'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="error"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="group sec_header">
                    <label for="security_header">Security Header</label>
                   <input type="text" name="security_header" id="security_header" value="<?php echo e(old('security_header')); ?>" disabled>
                   <?php $__errorArgs = ['security_header'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="error"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <button class="btn primary">Create</button>
            <button type="reset" class="btn danger">Cancel</button>

        </form>
    </div>

    <?php if(session('success')): ?>
    <div class="toastr success">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>
  
  <?php if(session('error')): ?>
    <div class="toastr error">
      <?php echo e(session('error')); ?>

    </div>
  <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inner.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\laravel-10.x\resources\views/inner/user-apiManager.blade.php ENDPATH**/ ?>