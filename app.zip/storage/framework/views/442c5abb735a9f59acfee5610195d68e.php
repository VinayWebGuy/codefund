
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
    <div class="blocks">
        <div class="block">
            <span><?php echo e(format_number(15870)); ?></span>
            <span>Wallet Balance</span>
        </div>
        <div class="block">
            <span><?php echo e(format_number(4)); ?></span>
            <span>API Created</span>
        </div>
        <div class="block">
            <span><?php echo e(format_number(870500)); ?></span>
            <span>Completed Transactions</span>
        </div>
        <div class="block">
            <span><?php echo e(format_number(350)); ?></span>
            <span>Failed Transactions</span>
        </div>
    </div>
    <div class="table">
        <h4>Recent Transactions</h4>
        <table>
            <thead>
                <tr>
                    <th>#</th>
                    <th>Txn Id</th>
                    <th>Amount</th>
                    <th>Datetime</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>87878444545</td>
                    <td><?php echo e(format_number(250)); ?></td>
                    <td>2024-09-24 12:25 PM</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>1558745488445</td>
                    <td><?php echo e(format_number(4500)); ?></td>
                    <td>2024-09-24 12:25 PM</td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>8210488484125</td>
                    <td><?php echo e(format_number(580000)); ?></td>
                    <td>2024-09-24 12:25 PM</td>
                </tr>
                <tr>
                    <td>4</td>
                    <td>12547828989</td>
                    <td><?php echo e(format_number(250)); ?></td>
                    <td>2024-09-24 12:25 PM</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>1558745488445</td>
                    <td><?php echo e(format_number(18000)); ?></td>
                    <td>2024-09-24 12:25 PM</td>
                </tr>
                <tr>
                    <td>6</td>
                    <td>8210488484125</td>
                    <td><?php echo e(format_number(30631)); ?></td>
                    <td>2024-09-24 12:25 PM</td>
                </tr>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('inner.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\laravel-10.x\resources\views/inner/user-index.blade.php ENDPATH**/ ?>