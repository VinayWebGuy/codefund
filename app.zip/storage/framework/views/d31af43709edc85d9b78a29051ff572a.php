
<?php $__env->startSection('title', 'Balance Transfer'); ?>
<?php $__env->startSection('user-balance-transfer', 'active'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4>Balance Transfer</h4>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('inner.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\laravel-10.x\resources\views/inner/user-balanceTransfer.blade.php ENDPATH**/ ?>