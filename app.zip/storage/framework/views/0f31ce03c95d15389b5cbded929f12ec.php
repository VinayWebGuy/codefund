</div>
</div>

<div class="authenticated">
   You are logged in as <?php echo e(Auth::user()->name); ?>

</div>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/prism/1.5.0/prism.min.js"></script>

<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\laravel-10.x\resources\views/inner/layouts/footer.blade.php ENDPATH**/ ?>